Common code
