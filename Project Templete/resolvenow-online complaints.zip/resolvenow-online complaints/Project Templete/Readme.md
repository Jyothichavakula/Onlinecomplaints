Project templete files

Project templete Link: https://drive.google.com/drive/folders/1ekDHcdiQcIvU-KXCrTd8KpEHrkdWO8c2?usp=sharing
