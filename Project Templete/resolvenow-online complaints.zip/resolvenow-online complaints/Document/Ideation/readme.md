Ideation files
