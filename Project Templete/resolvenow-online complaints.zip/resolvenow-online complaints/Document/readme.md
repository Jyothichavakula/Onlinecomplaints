This pdf consists of the project details and
Project Report in pdf seperatly
Team Id LTVIP2025TMID57870

Project templete Link: https://drive.google.com/drive/folders/1ekDHcdiQcIvU-KXCrTd8KpEHrkdWO8c2?usp=sharing
