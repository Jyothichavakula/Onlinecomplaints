# ResolveNow-Your-Platform-for-Online-Complaints
#Team Id: LTVIP2025TMID57870

Project templete Link: https://drive.google.com/drive/folders/1ekDHcdiQcIvU-KXCrTd8KpEHrkdWO8c2?usp=sharing

Video Demo Link : https://drive.google.com/drive/folders/1pMz10tCKY5gHwHnXG-iUOcIX_VZhT4em?usp=sharing

Project code link: https://drive.google.com/drive/folders/1kZosuhbOE4cy9lmHuU_WNYTMu7nSQe51?usp=sharing
